// Loading required plugins
var gulp = require('gulp');
var sass = require('gulp-sass');
var prefix = require('gulp-autoprefixer');
var browserSync = require('browser-sync');
var postcss = require("gulp-postcss");
var cssimport = require("postcss-import");
var reload = browserSync.reload;

// Paths configuration
var paths = {
  // Sass in/out directories
  sass: {
    src: [
      'scss/**/*.scss'
    ],
    dst: '../../../web/css/'
  },
  // Reload browser window when some of these files are changed
  static: [
    '../views/**/*',
    'js/**/*'
  ],
  // In case we need to watch for changes for a code generated only by Assetic (no preprocessing)
  web: {
    css: [
      '../../../web/css/*.css'
    ]
  }
};

// We need this to inject CSS changed files
gulp.task('browser-sync', function() {
  browserSync({
    options: {
      server: {
        baseDir: './'
      }
    }
  });
});

// Manually reload all sessions connected to browser sync
gulp.task('static-reload', function () {
  browserSync.reload();
});

// Sass task, will run when any SCSS files change & BrowserSync
// will auto-update browsers
gulp.task('sass', function () {
  gulp.src(paths.sass.src)
    .pipe(
      sass()
        .on('error', sass.logError) // prevents stop watching on Sass error
    )
    .pipe(prefix("last 3 version", "> 1%", "ie 8", { cascade: true }))
    .pipe(postcss([cssimport]))
    .pipe(gulp.dest(paths.sass.dst))
    .pipe(reload({stream:true}));
});

// Static CSS from web/css/ directory
gulp.task('css', function () {
  return gulp.src(paths.web.css)
    .pipe(reload({stream:true}));
});

// Default task to be run with `gulp`
gulp.task('default', ['css', 'sass', 'browser-sync'], function () {
  gulp.watch(paths.sass.src, ['sass']);
  gulp.watch(paths.web.css, ['css']);
  gulp.watch(paths.static, ['static-reload']);
});
